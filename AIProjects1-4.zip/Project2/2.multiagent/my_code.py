1
#initialization of variables
        min_distance_to_food = 999999999
        min_distance_to_ghost = 999999999
        distance = 0 #to store the distance
        final_score = -999999999
        #get current location
        #get list of food
        #foodList = newFood.asList()
        #ghostList = newGhostStates.aslist()
        #consider food location
        #there is a ghost or a stop
        #if action == "stop":
            #return -9999999
        #consider ghost
        for ghost in newGhostStates:
            # it is eaten
            if ghost.scaredTimer == 0 and ghost.getPosition() == tuple(newPos):
                return -999999999
            #distance = manhattanDistance(ghost.getPosition(), newPos)
            #if distance < min_distance_to_ghost:
                #min_distance_to_ghost = distance
        distance = 0
        newPos = list(newPos)
        foodList = newFood.asList()
        for i in range(len(foodList)):
            distance = manhattanDistance(newFood.asList()[i], newPos)
            if distance < min_distance_to_food:
                min_distance_to_food = distance
        min_distance_to_food = - min_distance_to_food #thus we have higher score for the node closest to food
        
        final_score = min_distance_to_food + min_distance_to_ghost*0.1
        return min_distance_to_food

